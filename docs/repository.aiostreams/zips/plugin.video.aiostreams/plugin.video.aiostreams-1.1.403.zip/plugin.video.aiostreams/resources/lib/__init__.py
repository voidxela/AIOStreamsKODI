# Resources lib module
